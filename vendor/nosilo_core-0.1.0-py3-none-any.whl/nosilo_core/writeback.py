"""Safe-staging writeback control plane (capability M15).

The agent never mutates a client's system of record directly. It:
  1. STAGES a dry-run ``Changeset`` (field-level before/after) without writing;
  2. classifies it by RISK TIER (read / reversible / irreversible);
  3. requires a valid, matching, unexpired ``Approval`` for anything that is not
     auto-applicable under policy;
  4. APPLIES idempotently (the same idempotency_key never lands twice);
  5. records an AUDIT entry so any applied changeset can be ROLLED BACK.

This module is pure and ships an ``InMemoryStore`` reference implementation that
stands in for a real connector (ERP / Excel / DB). Real connectors implement the
same read/applied_keys/claim/release/commit/rollback surface; the safety logic
here is connector-agnostic.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import threading
import time
from dataclasses import dataclass

# Risk tiers, by reversibility/impact.
TIER_READ = "read"
TIER_REVERSIBLE = "reversible"        # a write that can be cleanly undone (e.g. set a field)
TIER_IRREVERSIBLE = "irreversible"    # a write that cannot be safely undone (e.g. send a PO)


class WritebackRefused(Exception):
    """Raised when an apply is blocked by the safety policy (missing/invalid approval)."""


def requires_approval(tier: str, *, auto_apply_reversible: bool = False) -> bool:
    """Whether a tier needs explicit human approval before it can be applied."""
    if tier == TIER_READ:
        return False
    if tier == TIER_REVERSIBLE:
        return not auto_apply_reversible
    return True  # irreversible always needs a human in the loop


@dataclass(frozen=True)
class Change:
    """A single field-level edit, as a dry-run before/after pair."""

    entity_id: str
    field: str
    before: object
    after: object

    @property
    def is_noop(self) -> bool:
        return self.before == self.after


def _content_hash(target: str, risk_tier: str, changes: tuple[Change, ...]) -> str:
    """Stable hash of what a changeset actually does (not its idempotency_key).

    Binding an ``Approval`` to this - not just to ``idempotency_key`` - closes the
    "approve X, apply Y" gap: a caller can no longer approve one set of edits and
    then apply a different changeset that happens to reuse the same key.
    """
    payload = repr((target, risk_tier, tuple((c.entity_id, c.field, c.before, c.after) for c in changes)))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class Changeset:
    """A staged, not-yet-applied set of changes against one target system."""

    target: str
    changes: tuple[Change, ...]
    risk_tier: str
    idempotency_key: str
    reason: str = ""

    @property
    def is_noop(self) -> bool:
        return all(c.is_noop for c in self.changes)

    @property
    def content_hash(self) -> str:
        return _content_hash(self.target, self.risk_tier, self.changes)

    def summary(self) -> str:
        n = sum(1 for c in self.changes if not c.is_noop)
        return f"{n} change(s) to {self.target} [{self.risk_tier}] key={self.idempotency_key}"


def _approval_secret() -> str:
    """Server-side secret used to sign approvals. Empty disables signing (local/dev/tests),
    matching the ``LINCHPIN_API_KEY``/``LINCHPIN_RATE_LIMIT`` "empty disables the gate"
    convention already used in ``webapp/security.py``. Set for any deployment where
    ``approve()`` and ``apply()`` may not be the only code with access to this module.
    """
    return os.environ.get("LINCHPIN_APPROVAL_SECRET", "").strip()


def _sign_approval(changeset_key: str, content_hash: str, approved_by: str, expires_at: float) -> str:
    """HMAC-SHA256 over the approval's fields, keyed by a secret only ``approve()``
    (and whatever holds ``LINCHPIN_APPROVAL_SECRET``) can produce.

    Without this, ``Approval`` was a plain public dataclass: since ``content_hash`` is
    a deterministic hash of fields the caller already has, ANY code with access to this
    module could construct ``Approval(key, hash, "nobody", far_future_expiry)`` directly
    and satisfy ``matches()`` - no call to ``approve()``, no human, ever required. Signing
    means matching content and an unexpired timestamp are necessary but no longer
    sufficient; the signature can only be reproduced by whoever holds the secret.
    """
    secret = _approval_secret()
    payload = f"{changeset_key}:{content_hash}:{approved_by}:{expires_at!r}".encode()
    return hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()


@dataclass(frozen=True)
class Approval:
    """A time-boxed, signed authorization bound to one changeset's key AND its exact content."""

    changeset_key: str
    content_hash: str
    approved_by: str
    expires_at: float
    signature: str

    def is_valid_at(self, now: float) -> bool:
        return now < self.expires_at

    def matches(self, changeset: Changeset) -> bool:
        """Whether this approval was genuinely minted (by ``approve()``, i.e. signed with
        the server secret) for exactly this changeset's key and content."""
        if self.changeset_key != changeset.idempotency_key or self.content_hash != changeset.content_hash:
            return False
        expected = _sign_approval(self.changeset_key, self.content_hash, self.approved_by, self.expires_at)
        return hmac.compare_digest(self.signature, expected)


@dataclass(frozen=True)
class AuditEntry:
    """What was applied, by whom, and how to undo it."""

    idempotency_key: str
    target: str
    approved_by: str
    restore: tuple[tuple[str, str, object], ...]  # (entity_id, field, original_value)


@dataclass(frozen=True)
class ApplyResult:
    applied: bool
    idempotent_skip: bool = False
    audit_id: str | None = None


def approve(
    changeset: Changeset, approved_by: str, *, now: float | None = None, ttl_seconds: float = 900.0
) -> Approval:
    """Mint a signed approval valid for ``ttl_seconds`` from ``now``.

    ``now`` defaults to the real wall clock (``time.time()``); pass an explicit value
    only for deterministic tests. Bound to both the changeset's key and its content
    hash, so it cannot later validate a different changeset that reuses the same key -
    and signed (see ``_sign_approval``) so it cannot be forged by constructing
    ``Approval`` directly instead of calling this function.
    """
    if now is None:
        now = time.time()
    expires_at = now + ttl_seconds
    signature = _sign_approval(changeset.idempotency_key, changeset.content_hash, approved_by, expires_at)
    return Approval(changeset.idempotency_key, changeset.content_hash, approved_by, expires_at, signature)


class AuditBookkeeping:
    """Shared applied/audit bookkeeping for a writeback store.

    Backed by an in-memory dict, or - when ``ledger`` is given (e.g. a
    ``nosilo_core.writeback_store.SqliteAuditLedger``) - a persistent ledger that survives a
    process restart. Any store implementing read/commit/rollback (``InMemoryStore``
    below, or a real connector's system-of-record wrapper) composes this instead of
    re-deriving the same ledger-or-dict branching - including this class's
    ``claim()``/``release()`` atomicity primitive, so every such store gets it for free.

    ``_claims`` is a separate, ephemeral set of in-flight (claimed but not yet
    recorded) keys - kept apart from ``_applied`` so ``applied_keys()``/``get()``
    behavior is unchanged for every existing reader (e.g. ``rollback()``'s "is this
    key known" check): a key is only ever visible there once ``record()`` completes,
    exactly as before ``claim()`` existed.
    """

    def __init__(self, ledger: object | None = None) -> None:
        self._ledger = ledger
        self._applied: dict[str, AuditEntry] = {}
        self._claims: set[str] = set()
        self._claims_lock = threading.Lock()

    def applied_keys(self) -> set[str]:
        return self._ledger.applied_keys() if self._ledger is not None else set(self._applied)

    def claim(self, idempotency_key: str, *, now: float | None = None) -> bool:
        """Atomically reserve ``idempotency_key`` BEFORE any side-effecting write.

        Returns True if the caller now owns the key and must follow up with exactly
        one of ``record()`` (the write succeeded) or ``release()`` (it failed or was
        aborted). Returns False if the key is already claimed by another in-flight
        ``apply()`` call, or already fully recorded - the caller MUST NOT perform the
        side-effecting write and should treat this as an idempotent skip.

        This closes the check-then-act window ``apply()`` used to leave open: it used
        to check ``idempotency_key in store.applied_keys()`` and only THEN call
        ``store.commit()`` - two concurrent callers could both pass that check before
        either finished committing, and both perform the side-effecting write (e.g.
        both create a purchase order in Odoo for the same restock).

        ``now`` is only meaningful for a ledger-backed store (see
        ``nosilo_core.writeback_store.SqliteAuditLedger.claim`` - it bounds how long an
        orphaned claim from a crashed process can block a legitimate retry); the
        in-memory path below ignores it, since a crashed process's memory - claims
        included - is simply gone, with nothing left to go stale.
        """
        if self._ledger is not None:
            return self._ledger.claim(idempotency_key, now=now)
        with self._claims_lock:
            if idempotency_key in self._applied or idempotency_key in self._claims:
                return False
            self._claims.add(idempotency_key)
            return True

    def release(self, idempotency_key: str) -> None:
        """Release a claim that will NOT be followed by ``record()`` (the
        side-effecting write raised or was aborted) - lets a legitimate retry proceed
        instead of leaving the key permanently claimed. Only call this once the write
        it guarded has definitively failed; calling it speculatively while that write
        may still be genuinely in flight would let a second claimant through early."""
        if self._ledger is not None:
            self._ledger.release(idempotency_key)
        else:
            with self._claims_lock:
                self._claims.discard(idempotency_key)

    def record(self, entry: AuditEntry) -> None:
        if self._ledger is not None:
            self._ledger.record(entry)
        else:
            with self._claims_lock:
                self._applied[entry.idempotency_key] = entry
                self._claims.discard(entry.idempotency_key)

    def get(self, idempotency_key: str) -> AuditEntry | None:
        if self._ledger is not None:
            return self._ledger.get(idempotency_key)
        return self._applied.get(idempotency_key)

    def forget(self, idempotency_key: str) -> None:
        if self._ledger is not None:
            self._ledger.forget(idempotency_key)
        else:
            del self._applied[idempotency_key]


class InMemoryStore:
    """Reference system-of-record. Real connectors mirror read/claim/release/_commit/rollback.

    ``ledger``, when given, persists the applied/audit bookkeeping (e.g. a
    ``nosilo_core.writeback_store.SqliteAuditLedger``) so idempotency and rollback survive
    a process restart. Without one, bookkeeping lives in process memory exactly as
    before - fully backward compatible.
    """

    def __init__(self, records: dict | None = None, *, ledger: object | None = None) -> None:
        self._records: dict[str, dict] = {k: dict(v) for k, v in (records or {}).items()}
        self._audit = AuditBookkeeping(ledger)

    def read(self, entity_id: str) -> dict:
        return dict(self._records.get(entity_id, {}))

    def applied_keys(self) -> set[str]:
        return self._audit.applied_keys()

    def claim(self, idempotency_key: str, *, now: float | None = None) -> bool:
        return self._audit.claim(idempotency_key, now=now)

    def release(self, idempotency_key: str) -> None:
        self._audit.release(idempotency_key)

    def commit(self, changeset: Changeset, approved_by: str) -> AuditEntry:
        # Capture originals BEFORE writing, so rollback is exact.
        restore = tuple(
            (c.entity_id, c.field, self._records.get(c.entity_id, {}).get(c.field, ABSENT))
            for c in changeset.changes
        )
        for c in changeset.changes:
            self._records.setdefault(c.entity_id, {})[c.field] = c.after
        entry = AuditEntry(changeset.idempotency_key, changeset.target, approved_by, restore)
        self._audit.record(entry)
        return entry

    def rollback(self, idempotency_key: str) -> None:
        entry = self._audit.get(idempotency_key)
        if entry is None:
            raise KeyError(idempotency_key)
        for entity_id, fld, original in entry.restore:
            if original is ABSENT:
                self._records.get(entity_id, {}).pop(fld, None)
            else:
                self._records.setdefault(entity_id, {})[fld] = original
        self._audit.forget(idempotency_key)


# Shared "this field did not exist before the change" sentinel. Public (not
# module-private) so any real connector's system-of-record wrapper - and any
# persistent ledger serializing a `restore` tuple - can recognize it by
# identity instead of every store inventing its own equivalent sentinel.
ABSENT = object()


def stage(
    store: InMemoryStore,
    target: str,
    edits: dict[str, dict],
    *,
    risk_tier: str,
    idempotency_key: str,
    reason: str = "",
) -> Changeset:
    """Compute a dry-run Changeset from current store values. Does NOT write."""
    changes: list[Change] = []
    for entity_id, fields in edits.items():
        current = store.read(entity_id)
        for fld, after in fields.items():
            changes.append(Change(entity_id, fld, current.get(fld), after))
    return Changeset(target, tuple(changes), risk_tier, idempotency_key, reason)


def apply(
    store: InMemoryStore,
    changeset: Changeset,
    *,
    approval: Approval | None = None,
    now: float | None = None,
    auto_apply_reversible: bool = False,
) -> ApplyResult:
    """Apply a staged changeset under the safety policy.

    ``now`` defaults to the real wall clock (``time.time()``) - pass an explicit
    value only for deterministic tests. Without this default, every production
    caller that omitted ``now`` was implicitly evaluating approvals at ``t=0``,
    so a 900s TTL never actually expired.

    Refuses (``WritebackRefused``) when approval is required but missing, does not
    match this exact changeset (key AND content), or is expired. Idempotent on
    ``idempotency_key`` - and safe under concurrency: the key is atomically claimed
    (``store.claim()``) before ``store.commit()`` ever runs, so two callers racing on
    the same key cannot both perform the side-effecting write. A caller that loses
    the claim gets the same ``idempotent_skip=True`` result as a sequential retry.
    Failing closed: if claiming or committing raises for any reason, no duplicate
    write is possible, but the exception still propagates (see below) rather than
    being reported as a normal refusal or skip.
    """
    if now is None:
        now = time.time()
    if requires_approval(changeset.risk_tier, auto_apply_reversible=auto_apply_reversible):
        if approval is None or not approval.matches(changeset) or not approval.is_valid_at(now):
            raise WritebackRefused(
                f"approval required for tier '{changeset.risk_tier}' and is missing/mismatched/expired"
            )

    # claim() itself can raise (e.g. a ledger-backed store surfacing a transient
    # SQLite error under real write contention, not just the IntegrityError it
    # already handles internally as a normal "someone else has it" signal) - that
    # must release the same as a failed commit(), not bypass cleanup by sitting
    # outside this block. BaseException (not just Exception) so an interrupt
    # (Ctrl-C mid-commit on a long-running CLI job) still releases the claim
    # instead of leaving a legitimate retry permanently blocked.
    try:
        if not store.claim(changeset.idempotency_key, now=now):
            return ApplyResult(applied=False, idempotent_skip=True, audit_id=changeset.idempotency_key)
        approved_by = approval.approved_by if approval is not None else "auto"
        entry = store.commit(changeset, approved_by)
    except BaseException:
        store.release(changeset.idempotency_key)
        raise
    return ApplyResult(applied=True, idempotent_skip=False, audit_id=entry.idempotency_key)
