"""Request/result DTOs for the orchestrator."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .guided import GuidedOutcome

STATUS_OK = "ok"
STATUS_NEEDS_CLARIFICATION = "needs_clarification"
STATUS_NEEDS_DATA = "needs_data"
STATUS_QA_FAILED = "qa_failed"
STATUS_ERROR = "error"


@dataclass(frozen=True)
class JobRequest:
    """A unit of work: a free-form brief, optional data, optional explicit routing."""

    brief: str
    data_path: str | None = None
    job_type: str | None = None
    params: dict = field(default_factory=dict)
    client: str = "Client"
    # Opt-in gate: when True, a tool whose required_client_params (see
    # nosilo_core/registry.py) aren't resolvable from params+client profile returns
    # needs_clarification instead of silently taking the engine's generic default.
    strict_params: bool = False


@dataclass(frozen=True)
class JobResult:
    """The outcome the orchestrator returns for a request."""

    status: str
    tool: str | None
    confidence: float
    deliverables: dict[str, str]
    summary: str
    qa_issues: list[str] = field(default_factory=list)
    clarifications: list[str] = field(default_factory=list)
    citations: list[str] = field(default_factory=list)  # L3 domain grounding (book/chapter)
    kb_warnings: list[str] = field(default_factory=list)  # surfaced when a knowledge graph is degraded
    guided: GuidedOutcome | None = None  # never-unprotected contract (Guided Execution Layer)
    # The tool's structured report (e.g. jobs.inventory_optimization.JobReport), for an
    # in-process caller that needs the numbers rather than the files (the harness in
    # src/simworld/). It is an arbitrary object: NEVER assume it is serializable, and
    # NEVER include it in an HTTP/MCP payload.
    report: object | None = None
